# Girofy — React + TypeScript + Tailwind + shadcn structure

Este projeto foi convertido da versão React/WebGL sem build para uma estrutura moderna Vite + React + TypeScript + Tailwind, preservando a experiência cinematográfica original e integrando a timeline GSAP solicitada.

## Estrutura

- `components/ui/timeline.tsx` — componente principal da timeline horizontal/pinada
- `components/ui/demo.tsx` — uso real adaptado à narrativa Girofy
- `src/main.tsx` — bootstrap React e montagem da experiência legada + timeline
- `src/legacy-app.js` — experiência Girofy original preservada
- `src/tailwind.css` — entrada Tailwind
- `styles.css` — design system/cinema original
- `public/portfolio` — 14 imagens WebP do portfólio
- `public/assets` — assets da marca
- `public/robots.txt`, `sitemap.xml`, `llms*.txt` — infraestrutura orgânica preservada

## Por que `/components/ui`

O projeto anterior não tinha estrutura shadcn. Foi criado o diretório raiz `/components/ui` e o alias `@/* -> ./*`, configurado em `vite.config.ts` e `tsconfig.app.json`. Isso mantém o import pedido `@/components/ui/timeline` estável e permite que componentes shadcn futuros sejam adicionados no mesmo lugar sem refatoração de imports.

## Dependências

```bash
npm install
```

`gsap` já está declarado em `package.json`. O componente usa `ScrollTrigger` e `SplitText`.

## Desenvolvimento

```bash
npm run dev
```

## Build

```bash
npm run build
```

A saída será criada em `dist/` e pode ser publicada em Vercel/Netlify ou outro host com suporte a build Vite.

## Integração da timeline

A timeline entra depois da experiência cinematográfica principal e antes da captura final. Ela foi adaptada para explicar o processo real da Girofy em sete camadas:

1. Diagnóstico
2. Arquitetura
3. Direção criativa
4. Protótipo
5. Motion + 3D
6. Conversão
7. Entrega

Nenhum provider de estado é necessário. O componente mantém estado apenas via refs e GSAP/ScrollTrigger. `prefers-reduced-motion` é respeitado.

## Responsividade

- Desktop: timeline horizontal ampla, seção pinada, milestones alternados acima/abaixo.
- Mobile: pista mais longa, cards/textos maiores e progressão horizontal controlada pelo scroll vertical.
- Resize: `ScrollTrigger.refresh()` recalcula medidas.

## Asset da timeline

O demo usa uma imagem conhecida do Unsplash via URL remota. Para performance máxima em produção, baixe a imagem e sirva em `public/assets` como WebP/AVIF.

## Observação de teste

Neste ambiente, `npm install` não concluiu por bloqueio/timeout de rede. Portanto a estrutura e o código foram montados, mas o build final não foi executado aqui. Em um ambiente com acesso ao npm, rode `npm install && npm run build`.
